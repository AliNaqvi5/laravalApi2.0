<?php

namespace Database\Seeders;

use App\Models\sensors;
use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class userSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
//        User::create(["name"=> "nodeJs", "email"=> "alimir57@gmail.com", "password" =>"12345"  ]);
//        User::create(["name"=> "Ali", "email"=> "alimir579@gmail.com", "password" =>"12345"  ]);
    }
}
