<?php $__env->startSection('content'); ?>

    <?php $createdAtPST = date('Y-m-d H:i:s', strtotime(($lux->created_at). ' +5 hours'));
                                $sunset = date_sunset(time(),SUNFUNCS_RET_STRING,24.8,67.0011,90,5) ; $sunrise =date_sunrise(time(),SUNFUNCS_RET_STRING,24.8,67.0011,90,5) ;
                                $createdAtPST = explode(" ",$createdAtPST)[1];
    ?>

    <div class="modal fade" id="alarmModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="alarmModalTitle">Alarm</h5>

                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body" id="alarmModalBody" style="color:red">

                </div>
                <div class="modal-footer">

                    <button type="button" class="btn btn-danger" id="alarmModalBtn" onclick="Acknowledge()">Acknowledge</button>
                </div>
            </div>
        </div>
    </div>

    <div class="toast" role="alert" aria-live="assertive" aria-atomic="true">
        <div class="toast-header">

            <strong class="mr-auto">Bootstrap</strong>
            <small class="text-muted">just now</small>
            <button type="button" class="ml-2 mb-1 close" data-dismiss="toast" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="toast-body">
            See? Just like this.
        </div>
    </div>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="row">
                <div class="sensor col-md-8">
                    <div class="card" >
                        <div class="card-header" style="text-align: left;"><?php echo e(__('Farm Details')); ?></div>
                        <div class="card-body">
                                        <table class="table table-striped">
                                            <tbody >
                                            <tr>
                                                <td><b>Farm Name</b></td>
                                                <td><?php echo e($farms->name); ?></td>
                                            </tr>
                                            <tr>
                                                <td><b>Farm Id</b></td>
                                                <td>FARM0123_<?php echo e($farms->id); ?></td>
                                            </tr>
                                            <tr>
                                                <td><b>Farm Location</b></td>
                                                <td><?php echo e($farms->location); ?></td>
                                            </tr>
                                            <tr>
                                                <td><b>Farm Area</b></td>
                                                <td><?php echo e($farms->area); ?></td>
                                            </tr>
                                            <tr>
                                                <td><b>Last Data Read</b></td>
                                                <td><?php echo e($createdAtPST); ?></td>
                                            </tr>
                                            <tr>
                                                <td><b>Sunrise Time</b></td>
                                                <td><?php echo e($sunrise); ?></td>
                                            </tr>
                                            <tr>
                                                <td><b>Sunset Time</b></td>
                                                <td><?php echo e($sunset); ?></td>
                                            </tr>
                                            </tbody>
                                        </table>
                        </div>
                    </div>
                </div>
                <div class="sensor col-md-4">
                <div class="card" >
                    <div class="card-header"><?php echo e(__('Water Tank Level and Pump Controls')); ?></div>
                    <div class="card-body" style="">
                        <label class="switch">
                            <input type="checkbox" <?php echo e($controls["pump"]->value=="on"? "checked" : ""); ?>>
                            <span class="slider round"></span>
                        </label>
                        <p style="display: inline;"> Water Pump Switch</p>
                        <p id="waterLevel" style="visibility: hidden;"><?php echo e($waterLevel->value); ?></p>
                        <div id="fluid-meter"></div>
                    </div>
                </div>
                </div>
            </div>
            <div class="row">
                <div class="sensor col-md-8">
                    <div class="card" >
                        <div class="card-header"><?php echo e(__('Temperature Sensor')); ?></div>
                        <div class="card-body">
                            <div class="gaugeTemp" data-digit=<?php echo e(round($temperature->value)); ?>>
                                <div class="gauge-outerTemp"></div>
                                <div class="gauge-innerTemp"></div>
                                <div class="gauge-digitsTemp"></div>
                            </div>
                            <h3 class="headingSensorGuage">Temperature (Celcius)</h3>
                        </div>
                    </div>
                </div>
                <div class="sensor col-md-4">
                    <div class="card" >
                        <div class="card-header"><?php echo e(__('Rain Sensor')); ?></div>
                        <div class="card-body" style="background: #233043;">
                            <?php if($rain->value === "Dry" ): ?>
                                <img src="<?php echo e(asset('img/noRainDark.png')); ?>" style=" width: 56%;">
                                <h3 class="headingSensorGuage dark" style="display: inline;">No Rain</h3>
                            <?php else: ?>
                                <img src="<?php echo e(asset('img/rainDark1.png')); ?>" style=" width: 56%;">
                                <h3 class="headingSensorGuage dark" style="display: inline;">Raining</h3>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="card" >
                        <div class="card-header"><?php echo e(__('Solar Intensity')); ?></div>
                        <div class="card-body">
                            


                            <?php if($sunrise < $createdAtPST && $sunset > $createdAtPST): ?>
                                <?php if($lux->value <= 1000 && $lux->value >= 500): ?>
                                    <img src="<?php echo e(asset('img/cloudy.png')); ?>" style=" width: 54%;">
                                    <h3 class="headingSensorGuage" style="display: inline;"><?php echo e($lux->value.' lux '); ?> <br><?php echo e("(Overcast DayLight)"); ?></h3>
                                <?php elseif($lux->value > 10000 && $lux->value < 25000): ?>
                                    <img src="<?php echo e(asset('img/ambientDay.png')); ?>" style=" width: 54%;">
                                    <h3 class="headingSensorGuage" style="display: inline;"><?php echo e($lux->value.' lux '); ?><br><?php echo e("(Ambient DayLight)"); ?></h3>
                                <?php elseif($lux->value > 25000 ): ?>
                                    <img src="<?php echo e(asset('img/directSunlight.png')); ?>" style=" width: 54%;">
                                    <h3 class="headingSensorGuage" style="display: inline;"><?php echo e($lux->value.' lux '); ?><br><?php echo e("(Direct SunLight)"); ?></h3>
                                <?php else: ?>
                                    <img src="<?php echo e(asset('img/Sun.jpg')); ?>" style=" width: 54%;">
                                    <h3 class="headingSensorGuage" style="display: inline;"><?php echo e($lux->value.' lux'); ?></h3>
                                <?php endif; ?>
                            <?php elseif($sunrise == $createdAtPST || $sunset == $createdAtPST): ?>
                                <img src="<?php echo e(asset('img/rise.png')); ?>" style=" width: 54%;">
                                <h3 class="headingSensorGuage" style="display: inline;"><?php echo e($lux->value.' lux '); ?><br><?php echo e("(Sun at horizon)"); ?></h3>
                            <?php elseif($sunrise > $createdAtPST || $sunset > $createdAtPST): ?>
                                <img src="<?php echo e(asset('img/Night.png')); ?>" style=" width: 54%;">
                                <h3 class="headingSensorGuage" style="display: inline;"> <?php echo e($lux->value.' lux'); ?><br><?php echo e(("Night")); ?></h3>

                            <?php endif; ?>
                        </div>
                    </div>

                </div>
            </div>
            <div class="row">
                <div class="sensor col-md-8">
                    <div class="card" >
                        <div class="card-header"><?php echo e(__('Humidity Sensor')); ?></div>
                        <div class="card-body">
                            <?php if(session('status')): ?>
                                <div class="alert alert-success" role="alert">
                                    <?php echo e(session('status')); ?>

                                </div>
                            <?php endif; ?>
                                <div class="gaugeHum" data-digit=<?php echo e(round($humidity->value)); ?>>
                                    <div class="gauge-outerHum"></div>
                                    <div class="gauge-innerHum"></div>
                                    <div class="gauge-digitsHum"></div>
                                </div>
                                <h3 class="headingSensorGuage">Humidity (%)</h3>
                        </div>
                    </div>

                </div>

                <div class="sensor col-md-4">
                    <div class="card" >
                        <div class="card-header"><?php echo e(__('Soil Moisture Sensor')); ?></div>
                        <div class="card-body">
                    <div class="outer-wrapper" style="margin-top: 101px;margin-left: 91px;margin-right: auto;">
                        <div class="column-wrapper">
                            <div class="column"></div>
                        </div>
                        <div class="percentage"><?php echo e($soilMoisture->value); ?></div>
                        <div class="value">soil moisture</div>
                    </div>
                    <h3 class="headingSensorGuage">Soil Moisture (%)</h3>
                        </div></div>
                </div>

            </div>
<script>
    var fm = new FluidMeter();
    fm.init({
        targetContainer: document.getElementById("fluid-meter"),
        fillPercentage: 15,
        options: {
            fontSize: "50px",
            fontFamily: "Arial",
            fontFillStyle: "#ffffff",
            drawShadow: true,
            drawText: true,
            drawPercentageSign: true,
            drawBubbles: false,
            size: 250,
            borderWidth: 5,
            backgroundColor: "#ffffff",
            foregroundColor: "#016e9b",
            foregroundFluidLayer: {
                fillStyle: "#15b0f5",
                angularSpeed: 70,
                maxAmplitude: 12,
                frequency: 30,
                horizontalSpeed: -50
            },
            backgroundFluidLayer: {
                fillStyle: "#0489c0",
                angularSpeed: 70,
                maxAmplitude: 9,
                frequency: 30,
                horizontalSpeed: 50
            }
        }
    });
    fm.setPercentage($("#waterLevel").html());

</script>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravalApi\resources\views/home.blade.php ENDPATH**/ ?>